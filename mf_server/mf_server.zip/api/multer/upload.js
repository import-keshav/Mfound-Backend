const multer = require('multer');
const multerS3 = require('multer-s3');
const s3 = require('../credentials/aws-s3');

const upload = multer({
  storage: multerS3({
    s3: s3,
    bucket: process.env.AWS_BUCKET_NAME_S3,
    contentType: multerS3.AUTO_CONTENT_TYPE,
    acl: 'public-read',
    
    key: function (req, file, cb) {
      let fileName = file.originalname;
      switch(file.fieldname){
        case 'lost_image':
        cb(null, "mfound-app/lost/"+fileName+"");
        break;
        case 'found_image':
        cb(null, "mfound-app/found/"+fileName+"");
        break;
        case 'docs_image':
        cb(null, "mfound-app/docs/"+fileName+"");
        break;
        case 'enquiry_image':
        cb(null, "mfound-app/enquiry/"+fileName+"");
        break;
        case 'image':
        cb(null, "mfound-app/profiles/"+fileName+"");
        break;
      }
      
    }
  })
}).any()

module.exports = banner_upload;
